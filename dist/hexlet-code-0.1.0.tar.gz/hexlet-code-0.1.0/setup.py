# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/shizomanya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/shizomanya/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/b862fbdeb3d4fdd4535e/maintainability)](https://codeclimate.com/github/shizomanya/python-project-49/maintainability)\n\n### Description:\nA Brain Games is a collection of five simple console games. Each game asks questions that must be answered correctly. After three correct answers, the game is considered completed. Wrong answers end the game and prompt you to play it again.\n\n### Games:\n- Brain-Even: Parity check.\n- Brain-Calc: Arithmetic calculations.\n- Brain-Gcd: Calculating the greatest common factor.\n- Brain-Progression: Searching for missing numbers in the arithmetic progression of numbers.\n- Brain-Prime: Definition of a prime number.\n\n### Askinema games:\n- brain-even: \'Answer "yes" if the number is even, otherwise answer "no".\'\n\n\n[![asciicast]()]\n\n- brain-calc: \'What is the result of the expression?\'\n\n[![asciicast]()]\n\n- brain-gcd: \'Find the greatest common divisor of given numbers.\'\n\n[![asciicast]()]\n\n- brain-progression: \'What number is missing in the progression?\'\n\n[![asciicast]()]\n\n- brain-prime: \'Answer "yes" if given number is prime. Otherwise answer "no".\'\n\n[![asciicast]()]\n',
    'author': 'shizomanya',
    'author_email': 'mistic_aa@inbox.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
